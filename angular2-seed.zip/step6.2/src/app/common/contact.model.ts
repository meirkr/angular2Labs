export class Contact{
    name:string;
    email:string;
    content:string;    
}