
import {Component} from "@angular/core";
@Component({
  selector:'nav-menu',
  templateUrl:'./navMenu.component.html'
})
export class NavMenuComponent{

  constructor(){}
}
