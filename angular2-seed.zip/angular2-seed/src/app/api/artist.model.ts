export class Artist {
    mbid: string;
    name: string;
    url: string;
}



